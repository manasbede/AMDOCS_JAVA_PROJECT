package com.amdocs.project.db;
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
public class DataSourceUtil {


	public static DataSource dataSource() {
		try {
			org.apache.commons.dbcp.BasicDataSource ds = new BasicDataSource();
			ds.setDriverClassName("com.mysql.cj.jdbc.Driver");
			ds.setUrl("jdbc:mysql://localhost:3306/project");
			ds.setUsername("root");
			ds.setPassword("root");
			return ds;
		} catch (Exception ex) {
			return null;
		}
	}
}